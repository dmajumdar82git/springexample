package com.dm.xml.springdi;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Run {

	public static void main(String[] args) {
	/*
	 * without spring framework approach
	 * Student stud=new Student();
	stud.setName("debasri");
	*/
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("container.xml");
		System.out.println("xml loaded");
/*Student student1=context.getBean("stud",Student.class);
		student1.display();
Student student2=context.getBean("stud1",Student.class);
		student2.display();*/
Student student3=context.getBean("stud2",Student.class);
	    student3.display();
Student student=context.getBean("sd",Student.class);
	    student.display();
	    student.getExam().getResult();
	    context.close();
	}

}
