package com.dm.xml.springioc;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.dm.stereotype.SIM;


public class UseBean {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("container.xml");
		System.out.println("xml loaded");
		/*
		 * Airtel airtel=(Airtel)context.getBean("airtel");
		airtel.calling();
		airtel.data();
		Vodafon vodafon=(Vodafon)context.getBean("vodafon");
		vodafon.calling();
		vodafon.data();
	*/
		//best practice
		SIM sim=context.getBean("sim",SIM.class);
		sim.calling();sim.data();
		context.close();
	}

}
