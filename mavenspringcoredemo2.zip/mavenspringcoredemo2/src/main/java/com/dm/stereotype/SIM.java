package com.dm.stereotype;

public interface SIM {
	void calling();
	void data();
	
}
