package com.dm.stereotype;
public class Airtel implements SIM {
	public void calling() {
		System.out.println("calling using airtel sim");
	}
	public void data() {
		System.out.println("using airtel internet");
		
	}

}
