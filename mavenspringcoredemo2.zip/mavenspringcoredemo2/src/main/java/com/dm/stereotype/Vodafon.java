package com.dm.stereotype;
public class Vodafon implements SIM{
	public void calling() {
		System.out.println("calling using Vodafon sim");
	}
	public void data() {
		System.out.println("using Vodafon internet");
		
	}


}
