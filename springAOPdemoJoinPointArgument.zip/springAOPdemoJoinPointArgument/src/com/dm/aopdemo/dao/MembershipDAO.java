package com.dm.aopdemo.dao;
import org.springframework.stereotype.Component;

import com.dm.aopdemo.Account;

@Component
public class MembershipDAO {
	public void addAccount(Account ac)
	{
		System.out.println("Adding account: "+getClass());
	}
	public void addService(boolean b,double d)
	{
		System.out.println("Adding account: "+getClass());
	}
}
