package com.dm.aopdemo.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {

	public void addAccount(int a,long c,String s)
	{
		System.out.println("Adding account: "+getClass());
	}
}
