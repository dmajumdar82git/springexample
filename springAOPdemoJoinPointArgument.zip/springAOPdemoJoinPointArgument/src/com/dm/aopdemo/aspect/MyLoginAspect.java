package com.dm.aopdemo.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.dm.aopdemo.Account;

import org.aspectj.lang.JoinPoint;
@Aspect
@Component
public class MyLoginAspect {
	
	@Before("execution(* add*(..))")
		public void beforeAddAccount(JoinPoint jp)
	{
		
		System.out.println("executing @Before advice on addAccount() ");
		//display method signature
		MethodSignature methodSig=(MethodSignature)jp.getSignature();
		System.out.println("method: "+methodSig);
		//display method argument
		Object arg[]=jp.getArgs();
		for(Object o:arg)
			{System.out.println("agument=>: "+o);
	if(o instanceof Account)
	{
		Account acc=(Account)o;
		System.out.println("Account name: "+acc.getName());
			
	}
	
			}
		
		
	}
}
