package com.dm.aopdemo.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoginAspect {
//this is where we add all of our related advices for logging
	
	
	//@Before advice
	//@Before("execution(public void com.dm.aopdemo.dao.AccountDAO.addAccount())")
	//@Before("execution(public void com.dm.aopdemo.dao.MembershipDAO.addAccount())")
	//@Before("execution(public void addAccount())")
	//@Before("execution(public void add*())")
	//@Before("execution(* void add*())")
	//@Before("execution(void add*())")
	//@Before("execution(public boolean add*())")
	//@Before("execution(* add*())")
	//@Before("execution(* * add*())")//     !!!!error!!!
	//@Before("execution(* add*(com.dm.aopdemo.Account))")
	//@Before("execution(* add*(com.dm.aopdemo.Account,..))")
	//@Before("execution(* add*(..))")
	//@Before("execution(* add*(*))")
	//@Before("execution(* com.dm.aopdemo.dao.*.*(..))")//specific package any class any method
	public void beforeAddAccount()
	{
		
		System.out.println("executing @Before advice on addAccount()");
		
	}
}
