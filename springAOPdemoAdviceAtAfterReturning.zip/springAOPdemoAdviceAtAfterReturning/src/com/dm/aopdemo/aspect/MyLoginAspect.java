package com.dm.aopdemo.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.dm.aopdemo.Account;
@Aspect
@Component
public class MyLoginAspect {
//this is where we add all of our related advices for logging
	@After("execution(* com.dm.aopdemo.dao.*.find*())")
	public void afterFindAccounts()
	{
		System.out.println("executing @after advice on findAccounts()");
	}
	
	@AfterReturning(pointcut="execution(* com.dm.aopdemo.dao.*.find*())",
			        returning="result")
	public void afterFindAccountsRetun(JoinPoint jp,List<Account> result)
	{
		
		String method=jp.getSignature().toShortString();
		System.out.println("from after returnning advice printing method name:=>"+method);
		System.out.println("Printing return value from after advice....\n"+result+"\n after modification from AOP...\n");
		//modifying data(add/remove/update)
		
		for(Account temp:result)
		{
			String uppname=temp.getName().toUpperCase();
			temp.setName(uppname);
		}
		
		
	}
}
