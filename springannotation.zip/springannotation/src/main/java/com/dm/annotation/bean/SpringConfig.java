package com.dm.annotation.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:student.properties")
public class SpringConfig {
	
	@Bean
	public Student myStud()
	{
		
		Student s=new Student(myExam("A+"));
		System.out.println("loading stud");
		return s;}
	
	@Bean
	public Exam myExam(String res)
	{
		Exam e=new Exam(res);
		System.out.println("loading exam");
		return e;}
	

	
}
