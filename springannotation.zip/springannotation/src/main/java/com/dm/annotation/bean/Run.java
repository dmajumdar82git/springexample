package com.dm.annotation.bean;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Run {

	public static void main(String[] args) {
	
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
		System.out.println("container loaded");
		Student stud=context.getBean("myStud",Student.class);
		stud.display();
		stud.showResut();
		
	context.close();
	}

}
