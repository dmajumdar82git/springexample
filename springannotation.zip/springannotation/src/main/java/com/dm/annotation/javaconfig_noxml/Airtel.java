package com.dm.annotation.javaconfig_noxml;

import org.springframework.stereotype.Component;

@Component("simA")
public class Airtel implements SIM {
	@Override
	public void calling() {
		// TODO Auto-generated method stub
		System.out.println("calling using airtel sim");
	}
	@Override
	public void data() {
		// TODO Auto-generated method stub
		System.out.println("using airtel internet");
	}
	@Override
	public void sms() {
		// TODO Auto-generated method stub
		System.out.println("using airtel messaging");
	}

	


}
