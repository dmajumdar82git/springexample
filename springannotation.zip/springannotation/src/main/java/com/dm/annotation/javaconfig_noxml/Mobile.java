package com.dm.annotation.javaconfig_noxml;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Mobile {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
		System.out.println("java configeration loaded");
		SIM sim=context.getBean("simA",SIM.class);
		sim.calling();
		sim.data();
		sim.sms();
		SIM sim2=context.getBean("vodafon",SIM.class);//id is given automatically
		sim2.calling();
		sim2.data();
		sim2.sms();
		context.close();
	}

}
