package com.dm.aopdemo.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoginAspect {
//this is where we add all of our related advices for logging
	
	
	@Pointcut("execution(* com.dm.aopdemo.dao.*.*(..))")
	private void hello() {}
	
	//create pointcut for getter
	@Pointcut("execution(* com.dm.aopdemo.dao.*.get*(..))")
	private void hello1() {}
	
	//create pointcut for setter
		@Pointcut("execution(* com.dm.aopdemo.dao.*.set*(..))")
		private void hello2() {}
		
		//create pointcut include all exclude  getter & setter
		@Pointcut("hello() && !(hello1() || hello2())")
		private void hello3() {}	
	
	//@Before("execution(* com.dm.aopdemo.dao.*.*(..) && !((* com.dm.aopdemo.dao.*.get*(..)) || (* com.dm.aopdemo.dao.*.set*(..))))")
	@Before("hello3()")
	public void beforeAddAccount()
	{
		
		System.out.println("executing @Before advice on addAccount()");
		
	}
}
