package com.dm.aopdemo.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {
private String name;
	public void addAccount()
	{
		System.out.println("Adding account: "+getClass());
	}
	public String getName() {
		System.out.println("calling getter");
		return name;
	}
	public void setName(String name) {
		System.out.println("calling setter");
		this.name = name;
	}
	
}
