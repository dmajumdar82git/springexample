package com.dm.annotation.javaconfig_noxml.dbdemo.model;
import java.sql.*;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dm.annotation.javaconfig_noxml.dbdemo.beans.UserDetails;

import com.dm.annotation.javaconfig_noxml.dbdemo.model.util.DBCon;

@Component
public class UserDaoImpl implements UserDao{
	@Autowired
	DBCon dbcon;
	@Override
	public List<UserDetails> show() throws Exception{
		Connection con=dbcon.getCon();
		Statement st=con.createStatement();
		System.out.println(123+" "+con);
		ResultSet rs=st.executeQuery("select id,name,city from user_details");
		List <UserDetails>usr=new ArrayList<UserDetails>();
		while(rs.next())
		{
		UserDetails ud=new UserDetails();
		ud.setId(rs.getInt("id"));
		ud.setName(rs.getString("name"));
		ud.setCity(rs.getString("city"));
		usr.add(ud);
		}
		return usr;
	}

	@Override
	public void take(UserDetails usr) throws Exception {
		Connection con=dbcon.getCon();
		PreparedStatement ps=con.prepareStatement("insert into userdetails values(?,?,?)");
		ps.setInt(1,usr.getId());
		ps.setString(2,usr.getName());
		ps.setString(3,usr.getCity());
		ps.execute();
	}

}
