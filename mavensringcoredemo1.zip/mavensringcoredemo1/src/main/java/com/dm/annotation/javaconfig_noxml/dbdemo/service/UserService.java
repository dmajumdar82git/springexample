package com.dm.annotation.javaconfig_noxml.dbdemo.service;
import com.dm.annotation.javaconfig_noxml.dbdemo.beans.UserDetails;
import java.util.List;
public interface UserService {

	public List<UserDetails>display();
	public void insert(UserDetails usr);
}
