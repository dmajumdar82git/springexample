package com.dm.annotation.javaconfig_noxml.dbdemo;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.dm.annotation.javaconfig_noxml.dbdemo.beans.UserDetails;
import com.dm.annotation.javaconfig_noxml.dbdemo.service.UserService;
public class Run {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
		System.out.println("java config loaded");
		UserService userService=context.getBean("userServiceImpl",UserService.class);
		List<UserDetails> list=userService.display();
		if(list.size()>0)
		{
			for(UserDetails u:list)
			{
				System.out.println("Name: "+u.getName()+"\t Id: "+u.getId()+"\t City: "+u.getCity());	
			}
     	}
	context.close();
	}

}
