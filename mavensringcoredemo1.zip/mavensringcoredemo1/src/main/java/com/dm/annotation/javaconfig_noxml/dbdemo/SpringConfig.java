package com.dm.annotation.javaconfig_noxml.dbdemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan({"com.dm.annotation.javaconfig_noxml.dbdemo"})
@PropertySource("datasource/db.properties")
public class SpringConfig {

}
