package com.dm.aopdemo;

public class Account {
private String name;
private int no;
public Account() {
	
}
public Account(String name,int no) {
	super();
	this.name = name;
	this.no=no;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
public int getNo() {
	return no;
}
public void setNo(int no) {
	this.no = no;
}
@Override
public String toString() {
	return "Account [name=" + name + ", no=" + no + "]";
}



}
