package com.dm.aopdemo.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.dm.aopdemo.Account;


@Aspect
@Component
public class MyLoginAspect {
//this is where we add all of our related advices for logging
	
	
	//@After advice
	//@After advice
	
		@Before("execution(* cal())")
		public void beforeCal()
		{
			
			System.out.println("executing @before advice on cal method()");
		
			
		}
		@After("execution(* cal())")
		public void afterCal()
		{
			
			System.out.println("executing @after advice on cal method()");
		
			
		}
		@AfterThrowing(pointcut="execution(* cal())",
				       throwing="result")
		public void afterthrowCal(JoinPoint jp,Throwable result)
		{
			
			System.out.println("executing @after advice on throw of  cal method()");
		System.out.println("printing excaption: =>\n"+result+"\n\n");
			
		}
		
	}
